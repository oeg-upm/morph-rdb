CREATE TABLE "Student" (
"Name" varchar(50)
);
INSERT INTO "Student" ("Name") VALUES ('Venus');
